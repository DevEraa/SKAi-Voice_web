import React from 'react';
import Navbar from './Navbar';
import Audiocallpre from './Audiocallpre';

export default function AdminDashboard() {
  return (
   <>
   <Navbar />
    <Audiocallpre />
   </>
  )
}
