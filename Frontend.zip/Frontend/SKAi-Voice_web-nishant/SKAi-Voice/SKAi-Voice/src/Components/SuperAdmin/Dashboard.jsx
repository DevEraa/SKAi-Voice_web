import React from 'react';
import Navbar from './Navbar';
import Table from './AdminTable';

export default function Dashboard() {
  return (
   <>
   <Navbar />
   <Table />
   </>
  )
}
