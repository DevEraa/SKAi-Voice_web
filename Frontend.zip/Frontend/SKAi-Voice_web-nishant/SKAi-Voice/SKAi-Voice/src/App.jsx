import { useState } from 'react'
import './App.css'
import Routeing from './Components/Routeing/Index';
function App() {

  return (
    <>
      <Routeing />
    </>
  )
}

export default App
